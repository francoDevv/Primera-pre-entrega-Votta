from setuptools import setup

setup(
    name= "paquete1",
    version= 1.0,
    description= "primer paquete redistribuible",
    author= "Franco Votta",
    author_email= "votta.franco16@gmail.com",

    packages= ["paquete1"]
)
